package call;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class UserInfo {
	
    public String userID;
    public String gameID;
    public String token;
   
    
}
